package org.letsbuildrockets.libs;


/**
 * Designed to be a replacement for CANMessageNotFoundException that is not a runtime exception.
 * This allows us to avoid accidentally having robot code die due to not noticing the runtime
 * exception being thrown.
 */
public class CANMessageUnavailableException extends Exception {
	public CANMessageUnavailableException() {
		super();
	}

	public CANMessageUnavailableException(Throwable cause) {
		super(cause);
	}

	public CANMessageUnavailableException(String msg, Throwable cause) {
		super(msg, cause);
	}

	public CANMessageUnavailableException(String msg) {
		super(msg);
	}
}